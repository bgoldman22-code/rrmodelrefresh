// src/fgb_pack/weather.js
// Small, conservative placeholder (1.00).
// Optional: wire Open-Meteo later and cap effect to ±10% total.

export async function weatherHRMultiplier(parkName, dateISO){
  return 1.00;
}